from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.dependencies import get_db, get_current_user, require_nivel
from app.schemas.evento import EventoCreate, EventoUpdate, EventoOut
from app.models.evento import Evento

router = APIRouter(prefix="/eventos", tags=["Eventos"])


@router.get("/", response_model=list[EventoOut])
def listar(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return db.query(Evento).all()


@router.get("/{codigo}", response_model=EventoOut)
def detalhe(codigo: int, db: Session = Depends(get_db), _=Depends(get_current_user)):
    e = db.query(Evento).filter(Evento.Codigo == codigo).first()
    if not e:
        raise HTTPException(status_code=404, detail="Evento não encontrado")
    return e


@router.post("/", response_model=EventoOut, status_code=201)
def criar(data: EventoCreate, db: Session = Depends(get_db), _=Depends(require_nivel(2))):
    evento = Evento(**data.model_dump())
    db.add(evento)
    db.commit()
    db.refresh(evento)
    return evento


@router.put("/{codigo}", response_model=EventoOut)
def atualizar(codigo: int, data: EventoUpdate, db: Session = Depends(get_db), _=Depends(require_nivel(2))):
    evento = db.query(Evento).filter(Evento.Codigo == codigo).first()
    if not evento:
        raise HTTPException(status_code=404, detail="Evento não encontrado")
    for campo, valor in data.model_dump(exclude_unset=True).items():
        setattr(evento, campo, valor)
    db.commit()
    db.refresh(evento)
    return evento
