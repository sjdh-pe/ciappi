from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.dependencies import get_db, get_current_user, require_nivel
from app.schemas.acompanhamento import AcompanhamentoCreate, AcompanhamentoUpdate, AcompanhamentoOut
from app.services.acomp_service import criar_acompanhamento, atualizar_acompanhamento, listar_por_caso
from app.models.acompanhamento import Acompanhamento

router = APIRouter(prefix="/acompanhamentos", tags=["Acompanhamentos"])


@router.get("/caso/{num_caso}", response_model=list[AcompanhamentoOut])
def listar(num_caso: int, db: Session = Depends(get_db), _=Depends(get_current_user)):
    return listar_por_caso(db, num_caso)


@router.get("/{codigo}", response_model=AcompanhamentoOut)
def detalhe(codigo: int, db: Session = Depends(get_db), _=Depends(get_current_user)):
    a = db.query(Acompanhamento).filter(Acompanhamento.tbcodigo == codigo).first()
    if not a:
        raise HTTPException(status_code=404, detail="Acompanhamento não encontrado")
    return a


@router.post("/", response_model=AcompanhamentoOut, status_code=201)
def criar(data: AcompanhamentoCreate, db: Session = Depends(get_db), _=Depends(require_nivel(2))):
    try:
        return criar_acompanhamento(db, data)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.put("/{codigo}", response_model=AcompanhamentoOut)
def atualizar(codigo: int, data: AcompanhamentoUpdate, db: Session = Depends(get_db), _=Depends(require_nivel(2))):
    try:
        return atualizar_acompanhamento(db, codigo, data)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
