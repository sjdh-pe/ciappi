from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import date, datetime
from app.dependencies import get_db, get_current_user, require_nivel
from app.models.caso import Caso

router = APIRouter(prefix="/ouvidoria", tags=["Ouvidoria"])


@router.get("/avencer")
def casos_a_vencer(db: Session = Depends(get_db), _=Depends(get_current_user)):
    """Casos com prazo de ouvidoria próximo e não encerrados."""
    return (
        db.query(Caso)
        .filter(Caso.TbPrazoOuvidoria.isnot(None))
        .filter(Caso.TbEncerradoOuvidoria.is_(None))
        .all()
    )


@router.get("/concluidas")
def casos_concluidos(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return (
        db.query(Caso)
        .filter(Caso.TbEncerradoOuvidoria == "Sim")
        .all()
    )


@router.put("/{num_caso}/encerrar")
def encerrar_ouvidoria(
    num_caso: int,
    num_oficio: str,
    db: Session = Depends(get_db),
    _=Depends(require_nivel(2)),
):
    caso = db.query(Caso).filter(Caso.TbCasoNumCaso == num_caso).first()
    if not caso:
        raise HTTPException(status_code=404, detail="Caso não encontrado")
    caso.TbEncerradoOuvidoria = "Sim"
    caso.TbDtEncerradoOuvidoria = datetime.now()
    caso.TbNumOfOuvidoria = num_oficio
    db.commit()
    db.refresh(caso)
    return caso
