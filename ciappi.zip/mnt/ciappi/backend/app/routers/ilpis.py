from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.dependencies import get_db, get_current_user, require_nivel
from app.schemas.ilpi import ILPICreate, ILPIUpdate, ILPIOut
from app.models.ilpi import ILPI

router = APIRouter(prefix="/ilpis", tags=["ILPIs"])


@router.get("/", response_model=list[ILPIOut])
def listar(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return db.query(ILPI).all()


@router.get("/{codigo}", response_model=ILPIOut)
def detalhe(codigo: int, db: Session = Depends(get_db), _=Depends(get_current_user)):
    i = db.query(ILPI).filter(ILPI.CODIGOILPI == codigo).first()
    if not i:
        raise HTTPException(status_code=404, detail="ILPI não encontrada")
    return i


@router.post("/", response_model=ILPIOut, status_code=201)
def criar(data: ILPICreate, db: Session = Depends(get_db), _=Depends(require_nivel(2))):
    ilpi = ILPI(**data.model_dump())
    db.add(ilpi)
    db.commit()
    db.refresh(ilpi)
    return ilpi


@router.put("/{codigo}", response_model=ILPIOut)
def atualizar(codigo: int, data: ILPIUpdate, db: Session = Depends(get_db), _=Depends(require_nivel(2))):
    ilpi = db.query(ILPI).filter(ILPI.CODIGOILPI == codigo).first()
    if not ilpi:
        raise HTTPException(status_code=404, detail="ILPI não encontrada")
    for campo, valor in data.model_dump(exclude_unset=True).items():
        setattr(ilpi, campo, valor)
    db.commit()
    db.refresh(ilpi)
    return ilpi
