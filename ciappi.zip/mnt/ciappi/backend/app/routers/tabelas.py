from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.dependencies import get_db, get_current_user, require_nivel
from app.models.tabelas_aux import (
    MotivoAtendimento, MotivoEncerramento, TipoAcao,
    TipoEvento, ChegouPrograma, Orgao, Municipio, MotivoVisita
)
from app.models.tecnico import Tecnico

router = APIRouter(prefix="/tabelas", tags=["Tabelas Auxiliares"])


def _listar(db, model):
    return db.query(model).all()


@router.get("/motivos-atendimento")
def motivos_atendimento(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return _listar(db, MotivoAtendimento)


@router.get("/motivos-encerramento")
def motivos_encerramento(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return _listar(db, MotivoEncerramento)


@router.get("/tipo-acao")
def tipo_acao(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return _listar(db, TipoAcao)


@router.get("/tipo-evento")
def tipo_evento(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return _listar(db, TipoEvento)


@router.get("/origem")
def origem(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return _listar(db, ChegouPrograma)


@router.get("/orgaos")
def orgaos(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return _listar(db, Orgao)


@router.get("/municipios")
def municipios(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return _listar(db, Municipio)


@router.get("/tecnicos")
def tecnicos(db: Session = Depends(get_db), _=Depends(require_nivel(2))):
    return db.query(Tecnico).filter(Tecnico.TbStatus != "Inativo").all()


@router.get("/motivos-visita")
def motivos_visita(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return _listar(db, MotivoVisita)
