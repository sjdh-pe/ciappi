from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import datetime
from typing import Optional
from app.dependencies import get_db, get_current_user
from app.models.caso import Caso
from app.models.acompanhamento import Acompanhamento
from app.models.evento import Evento
from app.models.visita_inst import VisitaInst

router = APIRouter(prefix="/relatorios", tags=["Relatórios"])


@router.get("/casos-ativos")
def casos_ativos(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return db.query(Caso).filter(
        (Caso.TbCasoEncerrado.is_(None)) | (Caso.TbCasoEncerrado == "Não")
    ).all()


@router.get("/encerrados")
def encerrados(
    dt_ini: Optional[datetime] = Query(None),
    dt_fim: Optional[datetime] = Query(None),
    db: Session = Depends(get_db),
    _=Depends(get_current_user),
):
    q = db.query(Caso).filter(Caso.TbCasoEncerrado == "Sim")
    if dt_ini:
        q = q.filter(Caso.TbCasoDtencer >= dt_ini)
    if dt_fim:
        q = q.filter(Caso.TbCasoDtencer <= dt_fim)
    return q.all()


@router.get("/municipio")
def por_municipio(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return (
        db.query(Caso.TbCasoMunicipio, func.count(Caso.TbCasoNumCaso).label("total"))
        .group_by(Caso.TbCasoMunicipio)
        .order_by(func.count(Caso.TbCasoNumCaso).desc())
        .all()
    )


@router.get("/violencia")
def por_tipo_violencia(
    dt_ini: Optional[datetime] = Query(None),
    dt_fim: Optional[datetime] = Query(None),
    db: Session = Depends(get_db),
    _=Depends(get_current_user),
):
    q = db.query(
        Caso.TbCasoMotivoAtendimento,
        func.count(Caso.TbCasoNumCaso).label("total")
    ).group_by(Caso.TbCasoMotivoAtendimento)
    if dt_ini:
        q = q.filter(Caso.TbCasoDtinicio >= dt_ini)
    if dt_fim:
        q = q.filter(Caso.TbCasoDtinicio <= dt_fim)
    return q.all()


@router.get("/origem")
def por_origem(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return (
        db.query(Caso.TbCasoChegouPrograma, func.count(Caso.TbCasoNumCaso).label("total"))
        .group_by(Caso.TbCasoChegouPrograma)
        .all()
    )


@router.get("/acompanhamentos")
def acompanhamentos_periodo(
    dt_ini: Optional[datetime] = Query(None),
    dt_fim: Optional[datetime] = Query(None),
    db: Session = Depends(get_db),
    _=Depends(get_current_user),
):
    q = db.query(Acompanhamento)
    if dt_ini:
        q = q.filter(Acompanhamento.TbAcompdata >= dt_ini)
    if dt_fim:
        q = q.filter(Acompanhamento.TbAcompdata <= dt_fim)
    return q.all()


@router.get("/eventos")
def eventos_periodo(
    dt_ini: Optional[datetime] = Query(None),
    dt_fim: Optional[datetime] = Query(None),
    db: Session = Depends(get_db),
    _=Depends(get_current_user),
):
    q = db.query(Evento)
    if dt_ini:
        q = q.filter(Evento.TbDataRealizacao >= dt_ini)
    if dt_fim:
        q = q.filter(Evento.TbDataRealizacao <= dt_fim)
    return q.all()
