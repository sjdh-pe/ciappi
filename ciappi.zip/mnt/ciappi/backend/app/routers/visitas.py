from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.dependencies import get_db, get_current_user, require_nivel
from app.models.visita_inst import VisitaInst

router = APIRouter(prefix="/visitas", tags=["Visitas"])


@router.get("/inst")
def listar(db: Session = Depends(get_db), _=Depends(get_current_user)):
    return db.query(VisitaInst).all()


@router.get("/inst/{codigo}")
def detalhe(codigo: int, db: Session = Depends(get_db), _=Depends(get_current_user)):
    v = db.query(VisitaInst).filter(VisitaInst.codigovisita == codigo).first()
    if not v:
        raise HTTPException(status_code=404, detail="Visita não encontrada")
    return v


@router.post("/inst", status_code=201)
def criar(data: dict, db: Session = Depends(get_db), _=Depends(require_nivel(2))):
    visita = VisitaInst(**data)
    db.add(visita)
    db.commit()
    db.refresh(visita)
    return visita


@router.put("/inst/{codigo}")
def atualizar(codigo: int, data: dict, db: Session = Depends(get_db), _=Depends(require_nivel(2))):
    v = db.query(VisitaInst).filter(VisitaInst.codigovisita == codigo).first()
    if not v:
        raise HTTPException(status_code=404, detail="Visita não encontrada")
    for campo, valor in data.items():
        setattr(v, campo, valor)
    db.commit()
    db.refresh(v)
    return v
