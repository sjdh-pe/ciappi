from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional
from app.dependencies import get_db, get_current_user, require_nivel
from app.schemas.caso import CasoCreate, CasoUpdate, CasoOut, CasoRestaura
from app.services.caso_service import criar_caso, atualizar_caso, restaurar_caso, listar_casos
from app.models.caso import Caso

router = APIRouter(prefix="/casos", tags=["Casos"])


@router.get("/", response_model=list[CasoOut])
def listar(
    municipio: Optional[str] = Query(None),
    encerrado: Optional[str] = Query(None),
    tecnico: Optional[str] = Query(None),
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    _=Depends(get_current_user),
):
    return listar_casos(db, municipio, encerrado, tecnico, skip, limit)


@router.get("/{num_caso}", response_model=CasoOut)
def detalhe(num_caso: int, db: Session = Depends(get_db), _=Depends(get_current_user)):
    caso = db.query(Caso).filter(Caso.TbCasoNumCaso == num_caso).first()
    if not caso:
        raise HTTPException(status_code=404, detail="Caso não encontrado")
    return caso


@router.post("/", response_model=CasoOut, status_code=201)
def criar(data: CasoCreate, db: Session = Depends(get_db), _=Depends(require_nivel(2))):
    try:
        return criar_caso(db, data)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.put("/{num_caso}", response_model=CasoOut)
def atualizar(num_caso: int, data: CasoUpdate, db: Session = Depends(get_db), _=Depends(require_nivel(2))):
    try:
        return atualizar_caso(db, num_caso, data)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.put("/{num_caso}/restaurar", response_model=CasoOut)
def restaurar(num_caso: int, data: CasoRestaura, db: Session = Depends(get_db), _=Depends(require_nivel(2))):
    try:
        return restaurar_caso(db, num_caso, data.motivo_restauracao)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
