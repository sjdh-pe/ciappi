from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional
from app.dependencies import get_db, get_current_user, require_nivel
from app.models.usuario import Usuario
from app.services.usuario_service import criar_usuario, atualizar_usuario, buscar_por_nome

router = APIRouter(prefix="/usuarios", tags=["Usuários"])


@router.get("/")
def listar(nome: Optional[str] = Query(None), db: Session = Depends(get_db), _=Depends(get_current_user)):
    if nome:
        return buscar_por_nome(db, nome)
    return db.query(Usuario).limit(100).all()


@router.get("/{num_cadastro}")
def detalhe(num_cadastro: int, db: Session = Depends(get_db), _=Depends(get_current_user)):
    u = db.query(Usuario).filter(Usuario.tbnumerocadastro == num_cadastro).first()
    if not u:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")
    return u


@router.post("/", status_code=201)
def criar(data: dict, db: Session = Depends(get_db), _=Depends(require_nivel(2))):
    try:
        return criar_usuario(db, data)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.put("/{num_cadastro}")
def atualizar(num_cadastro: int, data: dict, db: Session = Depends(get_db), _=Depends(require_nivel(2))):
    try:
        return atualizar_usuario(db, num_cadastro, data)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
