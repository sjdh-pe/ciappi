from pydantic import BaseModel
from datetime import datetime
from typing import Optional


class EventoBase(BaseModel):
    tbtipoevento: str
    tbnomeevento: Optional[str] = None
    Tbobjetivoevento: Optional[str] = None
    Tbdataprevista: Optional[datetime] = None
    Tbpublicoalvo: Optional[str] = None
    TbPublicoEstimado: Optional[int] = None
    Tblocalevento: Optional[str] = None
    TbMunicipioevento: Optional[str] = None
    TbTecnicoResponsavel: Optional[int] = None


class EventoCreate(EventoBase):
    pass


class EventoUpdate(BaseModel):
    TbPublicoPresente: Optional[int] = None
    TbRelato: Optional[str] = None
    TbDataRealizacao: Optional[datetime] = None
    TbTempoDuracao: Optional[datetime] = None
    Tbtecnicosenvolvidos: Optional[int] = None


class EventoOut(EventoBase):
    Codigo: int
    TbPublicoPresente: Optional[int] = None
    TbRelato: Optional[str] = None
    TbDataRealizacao: Optional[datetime] = None

    class Config:
        from_attributes = True
