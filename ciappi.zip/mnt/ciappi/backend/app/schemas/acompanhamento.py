from pydantic import BaseModel, field_validator, model_validator
from datetime import datetime, date
from typing import Optional


class AcompanhamentoBase(BaseModel):
    TbAcomCaso: int
    TbAcompdata: datetime
    TbAcompAcao: str
    TbCaraterAtendimento: str
    TbRelato: str
    TbTecnicoResponsavel: str
    TbAcompOrgao: Optional[str] = None
    TbAcompStatus: Optional[str] = None
    TbAcompPrazo: Optional[datetime] = None

    @model_validator(mode="after")
    def validar_encaminhamento(self):
        if self.TbAcompAcao == "Encaminhamento" and not self.TbAcompOrgao:
            raise ValueError("Órgão é obrigatório quando a ação é Encaminhamento")
        return self

    @field_validator("TbAcompdata")
    @classmethod
    def data_nao_futura(cls, v):
        if v.date() > date.today():
            raise ValueError("Data não pode ser maior que hoje")
        return v


class AcompanhamentoCreate(AcompanhamentoBase):
    pass


class AcompanhamentoUpdate(BaseModel):
    TbAcompdata: Optional[datetime] = None
    TbAcompAcao: Optional[str] = None
    TbAcompOrgao: Optional[str] = None
    TbAcompStatus: Optional[str] = None
    TbAcompPrazo: Optional[datetime] = None
    TbCaraterAtendimento: Optional[str] = None
    TbRelato: Optional[str] = None
    TbTecnicoResponsavel: Optional[str] = None


class AcompanhamentoOut(AcompanhamentoBase):
    tbcodigo: int

    class Config:
        from_attributes = True
