from pydantic import BaseModel, field_validator
from datetime import datetime
from typing import Optional


class CasoBase(BaseModel):
    TbCasoNumCaso: int
    TbCasoDtinicio: datetime
    tbnomeidoso: str
    TbCasoMotivoAtendimento: str
    TbCasoChegouPrograma: str
    Tbambienteviolencia: Optional[str] = None
    TbCasoRelato: str
    TbCasoMunicipio: str
    TbCasoTecnicoResp: str

    @field_validator("tbnomeidoso", "TbCasoMunicipio", "TbCasoTecnicoResp")
    @classmethod
    def to_upper(cls, v):
        return v.upper() if v else v


class CasoCreate(CasoBase):
    pass


class CasoUpdate(BaseModel):
    tbnomeidoso: Optional[str] = None
    TbCasoDtinicio: Optional[datetime] = None
    TbCasoMotivoAtendimento: Optional[str] = None
    TbCasoChegouPrograma: Optional[str] = None
    Tbambienteviolencia: Optional[str] = None
    TbCasoRelato: Optional[str] = None
    TbCasoMunicipio: Optional[str] = None
    TbCasoTecnicoResp: Optional[str] = None
    TbCasoDtencer: Optional[datetime] = None
    TbCasoMotivoEncerramento: Optional[int] = None
    TbObservacoes: Optional[str] = None
    TbCasoEncerrado: Optional[str] = None
    TbNumDenuncia: Optional[int] = None
    TbPrazoOuvidoria: Optional[datetime] = None


class CasoOut(CasoBase):
    TbCasoDtencer: Optional[datetime] = None
    TbCasoMotivoEncerramento: Optional[int] = None
    TbCasoEncerrado: Optional[str] = None

    class Config:
        from_attributes = True


class CasoRestaura(BaseModel):
    motivo_restauracao: int
