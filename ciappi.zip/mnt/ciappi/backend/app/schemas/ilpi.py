from pydantic import BaseModel, field_validator
from datetime import datetime
from typing import Optional


class ILPIBase(BaseModel):
    NOMEILPI: str
    RESPONSAVELILPI: str
    TIPOENTIDADE: str
    CAPACIDADEIDOSOS: int
    IDOSOSRESIDENTES: int
    LOGRADOURO: str
    BAIRRO: str
    MUNICIPIO: str
    PERSONALIDADEJURIDICA: Optional[str] = None
    FONEFIXO: Optional[str] = None
    CELULAR: Optional[str] = None
    NUMEROIMOVEL: Optional[str] = None
    COMPLEMENTO: Optional[str] = None
    PONTODEREFERENCIA: Optional[str] = None
    STATUS: Optional[str] = None
    AVALIACAO: Optional[str] = None

    @field_validator("NOMEILPI", "RESPONSAVELILPI", "LOGRADOURO", "BAIRRO", "MUNICIPIO")
    @classmethod
    def to_upper(cls, v):
        return v.upper() if v else v


class ILPICreate(ILPIBase):
    DATACADASTRO: Optional[datetime] = None


class ILPIUpdate(BaseModel):
    RESPONSAVELILPI: Optional[str] = None
    CAPACIDADEIDOSOS: Optional[int] = None
    IDOSOSRESIDENTES: Optional[int] = None
    FONEFIXO: Optional[str] = None
    CELULAR: Optional[str] = None
    STATUS: Optional[str] = None
    AVALIACAO: Optional[str] = None
    DATAFECHAMENTO: Optional[datetime] = None
    DATAREABERTURA: Optional[datetime] = None


class ILPIOut(ILPIBase):
    CODIGOILPI: int
    DATACADASTRO: Optional[datetime] = None

    class Config:
        from_attributes = True
