from pydantic import BaseModel


class LoginRequest(BaseModel):
    nome: str
    senha: str


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    nivel: int
    nome: str
