from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import auth, casos, usuarios, acompanhamentos, ilpis, eventos, visitas, ouvidoria, relatorios, tabelas

app = FastAPI(
    title="CIAPPI API",
    description="Sistema de gestão de casos de proteção ao idoso — SJDH/PE",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8501"],  # Streamlit dev
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(casos.router)
app.include_router(usuarios.router)
app.include_router(acompanhamentos.router)
app.include_router(ilpis.router)
app.include_router(eventos.router)
app.include_router(visitas.router)
app.include_router(ouvidoria.router)
app.include_router(relatorios.router)
app.include_router(tabelas.router)


@app.get("/")
def root():
    return {"sistema": "CIAPPI", "versao": "1.0.0", "status": "online"}
