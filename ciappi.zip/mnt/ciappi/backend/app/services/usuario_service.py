from sqlalchemy.orm import Session
from datetime import date
from app.models.usuario import Usuario
from app.models.caso import Caso


def criar_usuario(db: Session, data: dict) -> Usuario:
    # Caso deve existir
    caso = db.query(Caso).filter(Caso.TbCasoNumCaso == data.get("tbcaso")).first()
    if not caso:
        raise ValueError(f"Caso {data.get('tbcaso')} não está cadastrado.")

    # Data de cadastro não pode ser futura
    dt_cadastro = data.get("tbdtcadastro")
    if dt_cadastro and dt_cadastro.date() > date.today():
        raise ValueError("Data de cadastro não pode ser maior que a data do dia.")

    usuario = Usuario(**data)
    db.add(usuario)
    db.commit()
    db.refresh(usuario)
    return usuario


def atualizar_usuario(db: Session, num_cadastro: int, data: dict) -> Usuario:
    usuario = db.query(Usuario).filter(Usuario.tbnumerocadastro == num_cadastro).first()
    if not usuario:
        raise ValueError("Usuário não encontrado.")
    for campo, valor in data.items():
        setattr(usuario, campo, valor)
    db.commit()
    db.refresh(usuario)
    return usuario


def buscar_por_nome(db: Session, nome: str) -> list[Usuario]:
    return db.query(Usuario).filter(Usuario.tbnome.ilike(f"%{nome}%")).all()
