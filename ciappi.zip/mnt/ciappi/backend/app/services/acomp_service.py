from sqlalchemy.orm import Session
from datetime import date
from app.models.acompanhamento import Acompanhamento
from app.models.caso import Caso
from app.schemas.acompanhamento import AcompanhamentoCreate, AcompanhamentoUpdate


def criar_acompanhamento(db: Session, data: AcompanhamentoCreate) -> Acompanhamento:
    # Caso deve existir
    caso = db.query(Caso).filter(Caso.TbCasoNumCaso == data.TbAcomCaso).first()
    if not caso:
        raise ValueError(f"Caso {data.TbAcomCaso} não está cadastrado.")

    # Prazo não pode ser menor que hoje
    if data.TbAcompPrazo and data.TbAcompPrazo.date() < date.today():
        raise ValueError("O prazo não pode ser menor que a data do dia.")

    acomp = Acompanhamento(**data.model_dump())
    db.add(acomp)
    db.commit()
    db.refresh(acomp)
    return acomp


def atualizar_acompanhamento(db: Session, codigo: int, data: AcompanhamentoUpdate) -> Acompanhamento:
    acomp = db.query(Acompanhamento).filter(Acompanhamento.tbcodigo == codigo).first()
    if not acomp:
        raise ValueError("Acompanhamento não encontrado.")

    updates = data.model_dump(exclude_unset=True)

    if "TbAcompAcao" in updates and updates["TbAcompAcao"] == "Encaminhamento":
        orgao = updates.get("TbAcompOrgao") or acomp.TbAcompOrgao
        if not orgao:
            raise ValueError("Informe o órgão para onde foi feito o encaminhamento.")

    for campo, valor in updates.items():
        setattr(acomp, campo, valor)

    db.commit()
    db.refresh(acomp)
    return acomp


def listar_por_caso(db: Session, num_caso: int) -> list[Acompanhamento]:
    return (
        db.query(Acompanhamento)
        .filter(Acompanhamento.TbAcomCaso == num_caso)
        .order_by(Acompanhamento.TbAcompdata.desc())
        .all()
    )
