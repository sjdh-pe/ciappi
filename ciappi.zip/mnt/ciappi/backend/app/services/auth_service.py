from sqlalchemy.orm import Session
from app.models.tecnico import Tecnico
from app.core.security import create_access_token


def autenticar(db: Session, nome: str, senha: str) -> dict | None:
    """
    Valida nome + senha do técnico (texto simples, como no Access original).
    Retorna token + dados do técnico ou None se inválido.
    """
    tecnico = (
        db.query(Tecnico)
        .filter(Tecnico.TbNomeTecnico == nome)
        .filter(Tecnico.TbSenha == senha)
        .first()
    )

    if not tecnico:
        return None

    if tecnico.TbStatus and tecnico.TbStatus.strip().lower() == "bloqueado":
        raise PermissionError("Usuário bloqueado. Procure a Coordenação.")

    token = create_access_token({"sub": str(tecnico.CodTecnico)})
    return {
        "access_token": token,
        "token_type": "bearer",
        "nivel": tecnico.TbNivel or 1,
        "nome": tecnico.TbNomeTecnico,
    }
