from sqlalchemy.orm import Session
from datetime import date
from app.models.caso import Caso
from app.schemas.caso import CasoCreate, CasoUpdate


def caso_existe(db: Session, num_caso: int) -> bool:
    return db.query(Caso).filter(Caso.TbCasoNumCaso == num_caso).first() is not None


def criar_caso(db: Session, data: CasoCreate) -> Caso:
    if caso_existe(db, data.TbCasoNumCaso):
        raise ValueError(f"Número de caso {data.TbCasoNumCaso} já existe.")
    caso = Caso(**data.model_dump())
    db.add(caso)
    db.commit()
    db.refresh(caso)
    return caso


def atualizar_caso(db: Session, num_caso: int, data: CasoUpdate) -> Caso:
    caso = db.query(Caso).filter(Caso.TbCasoNumCaso == num_caso).first()
    if not caso:
        raise ValueError("Caso não encontrado.")

    updates = data.model_dump(exclude_unset=True)

    # Regra: encerramento exige data + motivo juntos
    encerra_dt = updates.get("TbCasoDtencer") or caso.TbCasoDtencer
    encerra_mot = updates.get("TbCasoMotivoEncerramento") or caso.TbCasoMotivoEncerramento
    if (encerra_dt and not encerra_mot) or (encerra_mot and not encerra_dt):
        raise ValueError("Para encerrar o caso informe a Data e o Motivo de encerramento juntos.")

    for campo, valor in updates.items():
        setattr(caso, campo, valor)

    if encerra_dt and encerra_mot:
        caso.TbCasoEncerrado = "Sim"

    db.commit()
    db.refresh(caso)
    return caso


def restaurar_caso(db: Session, num_caso: int, motivo_restauracao: int) -> Caso:
    caso = db.query(Caso).filter(Caso.TbCasoNumCaso == num_caso).first()
    if not caso:
        raise ValueError("Caso não encontrado.")
    caso.TbCasoEncerrado = "Não"
    caso.TbCasoDtencer = None
    caso.TbCasoMotivoEncerramento = None
    db.commit()
    db.refresh(caso)
    return caso


def listar_casos(db: Session, municipio: str = None, encerrado: str = None,
                 tecnico: str = None, skip: int = 0, limit: int = 100):
    q = db.query(Caso)
    if municipio:
        q = q.filter(Caso.TbCasoMunicipio.ilike(f"%{municipio}%"))
    if encerrado is not None:
        q = q.filter(Caso.TbCasoEncerrado == encerrado)
    if tecnico:
        q = q.filter(Caso.TbCasoTecnicoResp.ilike(f"%{tecnico}%"))
    return q.offset(skip).limit(limit).all()
