from sqlalchemy import Column, Integer, String, DateTime
from app.database import Base


class ILPI(Base):
    __tablename__ = "TbCIAPPIILPI"

    CODIGOILPI = Column(Integer, primary_key=True, autoincrement=True)
    DATACADASTRO = Column(DateTime)
    NOMEILPI = Column(String(255), nullable=False)
    PERSONALIDADEJURIDICA = Column(String(255))
    RESPONSAVELILPI = Column(String(255))
    DATAVISITA = Column(DateTime)
    TIPOENTIDADE = Column(String(255))
    MOTIVOVISITA = Column(String(255))
    CAPACIDADEIDOSOS = Column(Integer)
    IDOSOSRESIDENTES = Column(Integer)
    TIPOPUBLICO = Column(String(255))
    FONEFIXO = Column(String(255))
    CELULAR = Column(String(255))
    LOGRADOURO = Column(String(255))
    NUMEROIMOVEL = Column(String(255))
    COMPLEMENTO = Column(String(255))
    BAIRRO = Column(String(255))
    MUNICIPIO = Column(String(255))
    PONTODEREFERENCIA = Column(String(255))
    DATAPREVISTAVISITA = Column(DateTime)
    STATUS = Column(String(255))
    AVALIACAO = Column(String(255))
    DATAFECHAMENTO = Column(DateTime)
    DATAREABERTURA = Column(DateTime)
