from sqlalchemy import Column, Integer, String, DateTime, Text
from app.database import Base


class Evento(Base):
    __tablename__ = "TbEvento"

    Codigo = Column("Código", Integer, primary_key=True, autoincrement=True)
    tbtipoevento = Column(String(255))
    tbnomeevento = Column(String(255))
    Tbobjetivoevento = Column(String(255))
    Tbdataprevista = Column(DateTime)
    Tbpublicoalvo = Column(String(255))
    TbPublicoEstimado = Column(Integer)
    Tblocalevento = Column(String(255))
    TbMunicipioevento = Column(String(255))
    TbTecnicoResponsavel = Column(Integer)
    TbPublicoPresente = Column(Integer)
    TbRelato = Column(Text)
    TbDataRealizacao = Column(DateTime)
    TbTempoDuracao = Column(DateTime)
    Tbtecnicosenvolvidos = Column(Integer)
