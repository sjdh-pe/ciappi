from sqlalchemy import Column, Integer, String, DateTime, Text
from app.database import Base


class Caso(Base):
    __tablename__ = "TbCIAPPICaso"

    TbCasoNumCaso = Column(Integer, primary_key=True)
    TbCasoDtinicio = Column(DateTime)
    tbnomeidoso = Column(String(255))
    TbCasoMotivoAtendimento = Column(String(255))
    TbCasoChegouPrograma = Column(String(255))
    Tbambienteviolencia = Column(String(255))
    TbCasoRelato = Column(Text)
    TbCasoMunicipio = Column(String(255), nullable=False)
    TbCasoNumInquerito = Column(Integer)
    TbCasoDtencer = Column(DateTime)
    TbObservacoes = Column(Text)
    TbCasoMotivoEncerramento = Column(Integer)
    TbCasoAvaliacaoUsuario = Column(Text)
    TbCasoTecnicoResp = Column(String(255))
    TbCasoEncerrado = Column(String(255))
    TbNumDenuncia = Column(Integer)
    TbPrazoOuvidoria = Column(DateTime)
    TbEncerradoOuvidoria = Column(String(255))
    TbDtEncerradoOuvidoria = Column(DateTime)
    TbNumOfOuvidoria = Column(String(255))
