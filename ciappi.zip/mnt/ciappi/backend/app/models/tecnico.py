from sqlalchemy import Column, Integer, String, DateTime
from app.database import Base


class Tecnico(Base):
    __tablename__ = "TbTecnico"

    CodTecnico = Column(Integer, primary_key=True, autoincrement=True)
    TbNomeTecnico = Column(String(255), nullable=False)
    TBCargoTecnico = Column(String(255))
    TbDataCadastro = Column(DateTime)
    TbDataSaida = Column(String(255))
    TbSenha = Column(String(255))
    TbNivel = Column(Integer)
    TbStatus = Column(String(255))
    Campo1 = Column(String(255))
