from sqlalchemy import Column, Integer, String
from app.database import Base


class MotivoAtendimento(Base):
    __tablename__ = "TbMotivoAtendimento"
    Codigo = Column("Código", Integer, primary_key=True, autoincrement=True)
    TbDescricaoMotivo = Column(String(255))


class MotivoEncerramento(Base):
    __tablename__ = "TbMotivoEncerramento"
    Codigo = Column("Código", Integer, primary_key=True, autoincrement=True)
    descricaomotivo = Column(String(255))


class MotivoRestauracao(Base):
    __tablename__ = "tbmotivorestauracao"
    Codigo = Column("Código", Integer, primary_key=True, autoincrement=True)
    DescricaoRestauracao = Column("DescriçãoRestauração", String(255))


class MotivoVisita(Base):
    __tablename__ = "TbMotivoVisita"
    Codigo = Column("Código", Integer, primary_key=True, autoincrement=True)
    motivovisita = Column(String(255))


class TipoAcao(Base):
    __tablename__ = "TbTipoAcao"
    CodAcao = Column("CodAção", Integer, primary_key=True, autoincrement=True)
    DescricaoAcao = Column(String(255))


class TipoEvento(Base):
    __tablename__ = "TbTipoEvento"
    codigo = Column(Integer, primary_key=True, autoincrement=True)
    tipoevento = Column(String(255), nullable=False)


class ChegouPrograma(Base):
    __tablename__ = "TbChegouPrograma"
    Codigo = Column("Código", Integer, primary_key=True, autoincrement=True)
    descricaochegouprograma = Column(String(255))


class Orgao(Base):
    __tablename__ = "TbOrgao"
    CodigoOrgao = Column(Integer, primary_key=True, autoincrement=True)
    TbNomeOrgao = Column(String(255))
    TbSiglaOrgao = Column(String(255))


class Municipio(Base):
    __tablename__ = "TbMunicipio"
    codigo = Column(Integer, primary_key=True, autoincrement=True)
    municipio = Column("município", String(255), nullable=False)
    AIS = Column(String(255))
    RD = Column(String(255))
