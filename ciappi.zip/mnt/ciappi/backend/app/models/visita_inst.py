from sqlalchemy import Column, Integer, String, DateTime, Text
from app.database import Base


class VisitaInst(Base):
    __tablename__ = "TbVisitaInst"

    codigovisita = Column(Integer, primary_key=True, autoincrement=True)
    nomeinstituicao = Column(String(255))
    datavista = Column(DateTime)
    assuntovisita = Column(String(255))
    responsavelinstituicao = Column(String(255))
    lembrete = Column(DateTime)
    relatorio = Column(Text)
    tecnicoresponsavel = Column(Integer)
