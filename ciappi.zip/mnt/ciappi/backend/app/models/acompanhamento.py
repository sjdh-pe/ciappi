from sqlalchemy import Column, Integer, String, DateTime, Text
from app.database import Base


class Acompanhamento(Base):
    __tablename__ = "TbCIAPPIAcompanhamento"

    tbcodigo = Column(Integer, primary_key=True, autoincrement=True)
    TbAcomCaso = Column(Integer, nullable=False)
    TbAcompdata = Column(DateTime)
    TbAcompOrgao = Column(String(255))
    TbAcompAcao = Column(String(255))
    TbAcompStatus = Column(String(255))
    TbAcompPrazo = Column(DateTime)
    TbCaraterAtendimento = Column(String(255))
    TbRelato = Column(Text)
    TbTecnicoResponsavel = Column(String(255))
