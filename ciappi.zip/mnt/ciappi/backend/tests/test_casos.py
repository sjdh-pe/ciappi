"""
Testes de integração para o módulo de casos.
Requer banco de dados de teste configurado.
"""
# TODO: implementar com pytest + banco em memória (SQLite) para CI


def test_placeholder():
    assert True
