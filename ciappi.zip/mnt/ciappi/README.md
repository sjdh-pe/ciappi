# CIAPPI — Sistema de Proteção ao Idoso

Sistema de gestão de casos sociais da **SJDH-PE**, migrado do Microsoft Access para **FastAPI + Streamlit**.

---

## Estrutura do Projeto

```
ciappi/
├── db/                  # Banco de dados MySQL
├── backend/             # API REST com FastAPI
└── frontend/            # Interface com Streamlit
```

---

## Como Rodar

### 1. Banco de Dados

```bash
cd db
docker compose up -d
```

> MySQL sobe na porta **3309** com charset `utf8mb4` e timezone `America/Recife`.

---

### 2. Backend (FastAPI)

```bash
cd backend
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# Configure o .env com DATABASE_URL e SECRET_KEY
uvicorn app.main:app --reload --port 8000
```

Documentação automática disponível em: `http://localhost:8000/docs`

---

### 3. Frontend (Streamlit)

```bash
cd frontend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

streamlit run app.py
```

Interface disponível em: `http://localhost:8501`

---

## Níveis de Acesso

| Nível | Acesso |
|-------|--------|
| 1     | Somente Monitoramento e Relatórios (leitura) |
| 2+    | Acesso completo (cadastro, edição, admin) |

---

## Regras de Negócio Principais

- Encerramento de caso exige **data + motivo** juntos
- Acompanhamento com ação **Encaminhamento** exige informar o **órgão**
- **Prazo** de acompanhamento não pode ser menor que hoje
- Nomes de idosos, ILPIs e municípios são salvos em **MAIÚSCULAS**
- Número do caso é **único** na tabela TbCIAPPICaso
- Usuário só pode ser cadastrado se o **caso já existir**

---

## Stack

| Camada    | Tecnologia                    |
|-----------|-------------------------------|
| Banco     | MySQL 8.0 (Docker)            |
| ORM       | SQLAlchemy 2.0                |
| API       | FastAPI + Pydantic v2         |
| Auth      | JWT (python-jose) + bcrypt    |
| Frontend  | Streamlit + Plotly            |
