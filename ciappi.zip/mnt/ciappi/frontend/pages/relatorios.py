import streamlit as st
import pandas as pd
import plotly.express as px
from api.client import get
from datetime import datetime, timedelta


def show():
    st.title("📊 Relatórios")
    aba = st.tabs([
        "Casos Ativos", "Encerrados", "Por Município",
        "Tipo de Violência", "Origem", "Acompanhamentos", "Eventos"
    ])

    with aba[0]:
        try:
            dados = get("/relatorios/casos-ativos")
            st.metric("Total de Casos Ativos", len(dados))
            if dados:
                df = pd.DataFrame(dados)[["TbCasoNumCaso", "tbnomeidoso", "TbCasoMunicipio",
                                           "TbCasoDtinicio", "TbCasoTecnicoResp"]]
                df.columns = ["Nº Caso", "Idoso", "Município", "Dt. Início", "Técnico"]
                st.dataframe(df, use_container_width=True)
        except Exception as e:
            st.error(f"Erro: {e}")

    with aba[1]:
        col1, col2 = st.columns(2)
        dt_ini = col1.date_input("De", value=datetime.today() - timedelta(days=365))
        dt_fim = col2.date_input("Até", value=datetime.today())
        if st.button("Gerar", key="enc"):
            try:
                dados = get("/relatorios/encerrados", {
                    "dt_ini": dt_ini.isoformat(), "dt_fim": dt_fim.isoformat()
                })
                st.metric("Casos Encerrados no Período", len(dados))
                if dados:
                    df = pd.DataFrame(dados)[["TbCasoNumCaso", "tbnomeidoso", "TbCasoMunicipio", "TbCasoDtencer"]]
                    df.columns = ["Nº Caso", "Idoso", "Município", "Dt. Encerramento"]
                    st.dataframe(df, use_container_width=True)
            except Exception as e:
                st.error(f"Erro: {e}")

    with aba[2]:
        if st.button("Gerar", key="mun"):
            try:
                dados = get("/relatorios/municipio")
                if dados:
                    df = pd.DataFrame(dados, columns=["Município", "Total"])
                    fig = px.bar(df, x="Município", y="Total", title="Casos por Município")
                    st.plotly_chart(fig, use_container_width=True)
                    st.dataframe(df, use_container_width=True)
            except Exception as e:
                st.error(f"Erro: {e}")

    with aba[3]:
        col1, col2 = st.columns(2)
        dt_ini = col1.date_input("De", value=datetime.today() - timedelta(days=365), key="vio_ini")
        dt_fim = col2.date_input("Até", value=datetime.today(), key="vio_fim")
        if st.button("Gerar", key="vio"):
            try:
                dados = get("/relatorios/violencia", {
                    "dt_ini": dt_ini.isoformat(), "dt_fim": dt_fim.isoformat()
                })
                if dados:
                    df = pd.DataFrame(dados, columns=["Tipo", "Total"])
                    fig = px.pie(df, names="Tipo", values="Total", title="Tipos de Violência")
                    st.plotly_chart(fig, use_container_width=True)
            except Exception as e:
                st.error(f"Erro: {e}")

    with aba[4]:
        if st.button("Gerar", key="ori"):
            try:
                dados = get("/relatorios/origem")
                if dados:
                    df = pd.DataFrame(dados, columns=["Origem", "Total"])
                    fig = px.bar(df, x="Origem", y="Total", title="Como Chegou ao Programa")
                    st.plotly_chart(fig, use_container_width=True)
            except Exception as e:
                st.error(f"Erro: {e}")

    with aba[5]:
        col1, col2 = st.columns(2)
        dt_ini = col1.date_input("De", value=datetime.today() - timedelta(days=90), key="acomp_ini")
        dt_fim = col2.date_input("Até", value=datetime.today(), key="acomp_fim")
        if st.button("Gerar", key="acomp"):
            try:
                dados = get("/relatorios/acompanhamentos", {
                    "dt_ini": dt_ini.isoformat(), "dt_fim": dt_fim.isoformat()
                })
                st.metric("Total de Acompanhamentos", len(dados))
                if dados:
                    df = pd.DataFrame(dados)[["tbcodigo", "TbAcomCaso", "TbAcompdata",
                                               "TbAcompAcao", "TbTecnicoResponsavel"]]
                    df.columns = ["Código", "Caso", "Data", "Ação", "Técnico"]
                    st.dataframe(df, use_container_width=True)
            except Exception as e:
                st.error(f"Erro: {e}")

    with aba[6]:
        col1, col2 = st.columns(2)
        dt_ini = col1.date_input("De", value=datetime.today() - timedelta(days=365), key="ev_ini")
        dt_fim = col2.date_input("Até", value=datetime.today(), key="ev_fim")
        if st.button("Gerar", key="ev"):
            try:
                dados = get("/relatorios/eventos", {
                    "dt_ini": dt_ini.isoformat(), "dt_fim": dt_fim.isoformat()
                })
                st.metric("Total de Eventos", len(dados))
                if dados:
                    df = pd.DataFrame(dados)
                    st.dataframe(df, use_container_width=True)
            except Exception as e:
                st.error(f"Erro: {e}")
