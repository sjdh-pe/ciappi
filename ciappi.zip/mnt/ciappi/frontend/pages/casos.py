import streamlit as st
from api.client import get, post, put
from datetime import datetime


def show():
    st.title("📁 Casos")
    aba = st.tabs(["Buscar / Listar", "Novo Caso", "Atualizar Caso"])

    # ── Buscar ──────────────────────────────────────────
    with aba[0]:
        col1, col2 = st.columns(2)
        municipio = col1.text_input("Município")
        encerrado = col2.selectbox("Status", ["Todos", "Não", "Sim"])
        if st.button("Buscar"):
            params = {}
            if municipio:
                params["municipio"] = municipio
            if encerrado != "Todos":
                params["encerrado"] = encerrado
            try:
                casos = get("/casos/", params)
                if casos:
                    import pandas as pd
                    df = pd.DataFrame(casos)[["TbCasoNumCaso", "tbnomeidoso", "TbCasoMunicipio",
                                               "TbCasoDtinicio", "TbCasoEncerrado", "TbCasoTecnicoResp"]]
                    df.columns = ["Nº Caso", "Idoso", "Município", "Dt. Início", "Encerrado", "Técnico"]
                    st.dataframe(df, use_container_width=True)
                else:
                    st.info("Nenhum caso encontrado.")
            except Exception as e:
                st.error(f"Erro: {e}")

    # ── Novo Caso ────────────────────────────────────────
    with aba[1]:
        with st.form("form_caso"):
            col1, col2 = st.columns(2)
            num_caso = col1.number_input("Nº do Caso*", min_value=1, step=1)
            dt_inicio = col2.date_input("Data de Início*")
            nome_idoso = st.text_input("Nome do Idoso*")
            col3, col4 = st.columns(2)
            municipio = col3.text_input("Município*")
            tecnico = col4.text_input("Técnico Responsável*")

            try:
                motivos = get("/tabelas/motivos-atendimento")
                opts_motivo = {m["TbDescricaoMotivo"]: m["Código"] for m in motivos}
            except Exception:
                opts_motivo = {}
            motivo = st.selectbox("Motivo do Atendimento*", list(opts_motivo.keys()))

            try:
                origens = get("/tabelas/origem")
                opts_origem = [o["descricaochegouprograma"] for o in origens]
            except Exception:
                opts_origem = []
            origem = st.selectbox("Como Chegou ao Programa*", opts_origem)

            relato = st.text_area("Síntese do Caso*", height=120)
            salvar = st.form_submit_button("Salvar Caso", use_container_width=True)

        if salvar:
            if not all([num_caso, nome_idoso, municipio, tecnico, motivo, origem, relato]):
                st.error("Todos os campos obrigatórios (*) devem ser preenchidos.")
            else:
                try:
                    post("/casos/", {
                        "TbCasoNumCaso": num_caso,
                        "TbCasoDtinicio": str(datetime.combine(dt_inicio, datetime.min.time())),
                        "tbnomeidoso": nome_idoso.upper(),
                        "TbCasoMotivoAtendimento": motivo,
                        "TbCasoChegouPrograma": origem,
                        "TbCasoRelato": relato,
                        "TbCasoMunicipio": municipio.upper(),
                        "TbCasoTecnicoResp": tecnico.upper(),
                    })
                    st.success(f"Caso {num_caso} registrado com sucesso!")
                except Exception as e:
                    st.error(f"Erro ao salvar: {e}")

    # ── Atualizar Caso ───────────────────────────────────
    with aba[2]:
        num_busca = st.number_input("Nº do Caso para editar", min_value=1, step=1, key="busca_atu")
        if st.button("Carregar Caso"):
            try:
                caso = get(f"/casos/{num_busca}")
                st.session_state["caso_edicao"] = caso
            except Exception:
                st.error("Caso não encontrado.")

        if "caso_edicao" in st.session_state:
            c = st.session_state["caso_edicao"]
            st.info(f"Editando: **{c['tbnomeidoso']}** — Caso nº {c['TbCasoNumCaso']}")
            with st.form("form_atu_caso"):
                relato = st.text_area("Síntese do Caso", value=c.get("TbCasoRelato", ""), height=120)
                col1, col2 = st.columns(2)
                dt_encer = col1.date_input("Data de Encerramento", value=None)
                try:
                    mot_enc = get("/tabelas/motivos-encerramento")
                    opts_enc = {m["descricaomotivo"]: m["Código"] for m in mot_enc}
                except Exception:
                    opts_enc = {"(sem dados)": None}
                motivo_enc = col2.selectbox("Motivo de Encerramento", [""] + list(opts_enc.keys()))
                salvar = st.form_submit_button("Salvar Alteração", use_container_width=True)

            if salvar:
                dados = {"TbCasoRelato": relato}
                if dt_encer:
                    dados["TbCasoDtencer"] = str(datetime.combine(dt_encer, datetime.min.time()))
                if motivo_enc and motivo_enc in opts_enc:
                    dados["TbCasoMotivoEncerramento"] = opts_enc[motivo_enc]
                try:
                    put(f"/casos/{c['TbCasoNumCaso']}", dados)
                    st.success("Alteração salva com sucesso!")
                    del st.session_state["caso_edicao"]
                except Exception as e:
                    st.error(f"Erro: {e}")
