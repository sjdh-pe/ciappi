import streamlit as st
from api.client import get, post
from datetime import datetime


def show():
    st.title("📋 Acompanhamentos")
    aba = st.tabs(["Ver por Caso", "Novo Acompanhamento"])

    with aba[0]:
        num_caso = st.number_input("Nº do Caso", min_value=1, step=1)
        if st.button("Buscar Acompanhamentos"):
            try:
                acomps = get(f"/acompanhamentos/caso/{num_caso}")
                if acomps:
                    import pandas as pd
                    df = pd.DataFrame(acomps)[[
                        "tbcodigo", "TbAcompdata", "TbAcompAcao",
                        "TbCaraterAtendimento", "TbTecnicoResponsavel"
                    ]]
                    df.columns = ["Código", "Data", "Ação", "Caráter", "Técnico"]
                    st.dataframe(df, use_container_width=True)
                    with st.expander("Ver relatos completos"):
                        for a in acomps:
                            st.markdown(f"**{a['TbAcompdata'][:10]}** — {a['TbAcompAcao']}")
                            st.text(a.get("TbRelato", ""))
                            st.divider()
                else:
                    st.info("Nenhum acompanhamento encontrado para este caso.")
            except Exception as e:
                st.error(f"Erro: {e}")

    with aba[1]:
        with st.form("form_acomp"):
            num_caso_inc = st.number_input("Nº do Caso*", min_value=1, step=1)
            col1, col2 = st.columns(2)
            data_acomp = col1.date_input("Data da Ação*")

            try:
                tipos = get("/tabelas/tipo-acao")
                opts_tipo = [t["DescricaoAcao"] for t in tipos]
            except Exception:
                opts_tipo = ["Visita Domiciliar", "Atendimento Individual", "Encaminhamento"]
            tipo_acao = col2.selectbox("Tipo de Ação*", opts_tipo)

            caráter = st.selectbox("Caráter do Atendimento*", [
                "Individual", "Familiar", "Comunitário", "Institucional"
            ])
            orgao = st.text_input("Órgão de Encaminhamento (obrigatório se ação = Encaminhamento)")
            prazo = st.date_input("Prazo (opcional)", value=None)
            relato = st.text_area("Relatório*", height=150)

            try:
                tecnicos = get("/tabelas/tecnicos")
                opts_tec = [t["TbNomeTecnico"] for t in tecnicos]
            except Exception:
                opts_tec = []
            tecnico = st.selectbox("Técnico Responsável*", opts_tec)

            salvar = st.form_submit_button("Salvar Acompanhamento", use_container_width=True)

        if salvar:
            try:
                dados = {
                    "TbAcomCaso": num_caso_inc,
                    "TbAcompdata": str(datetime.combine(data_acomp, datetime.min.time())),
                    "TbAcompAcao": tipo_acao,
                    "TbCaraterAtendimento": caráter,
                    "TbRelato": relato,
                    "TbTecnicoResponsavel": tecnico,
                }
                if orgao:
                    dados["TbAcompOrgao"] = orgao
                if prazo:
                    dados["TbAcompPrazo"] = str(datetime.combine(prazo, datetime.min.time()))
                post("/acompanhamentos/", dados)
                st.success("Acompanhamento registrado com sucesso!")
            except Exception as e:
                st.error(f"Erro: {e}")
