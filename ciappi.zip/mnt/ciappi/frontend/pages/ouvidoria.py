import streamlit as st
from api.client import get, put


def show():
    st.title("📣 Ouvidoria")
    aba = st.tabs(["A Vencer", "Concluídas", "Encerrar Ouvidoria"])

    with aba[0]:
        try:
            dados = get("/ouvidoria/avencer")
            if dados:
                import pandas as pd
                df = pd.DataFrame(dados)[["TbCasoNumCaso", "tbnomeidoso", "TbPrazoOuvidoria",
                                           "TbNumDenuncia", "TbCasoMunicipio"]]
                df.columns = ["Nº Caso", "Idoso", "Prazo", "Nº Denúncia", "Município"]
                st.dataframe(df, use_container_width=True)
            else:
                st.success("Nenhuma ouvidoria a vencer.")
        except Exception as e:
            st.error(f"Erro: {e}")

    with aba[1]:
        try:
            dados = get("/ouvidoria/concluidas")
            if dados:
                import pandas as pd
                df = pd.DataFrame(dados)[["TbCasoNumCaso", "tbnomeidoso",
                                           "TbDtEncerradoOuvidoria", "TbNumOfOuvidoria"]]
                df.columns = ["Nº Caso", "Idoso", "Dt. Encerramento", "Nº Ofício"]
                st.dataframe(df, use_container_width=True)
            else:
                st.info("Nenhuma ouvidoria concluída.")
        except Exception as e:
            st.error(f"Erro: {e}")

    with aba[2]:
        with st.form("form_encerra_ouvidoria"):
            num_caso = st.number_input("Nº do Caso*", min_value=1, step=1)
            num_oficio = st.text_input("Nº do Ofício*")
            salvar = st.form_submit_button("Encerrar Ouvidoria", use_container_width=True)

        if salvar:
            if not num_oficio:
                st.error("Informe o número do ofício.")
            else:
                try:
                    put(f"/ouvidoria/{num_caso}/encerrar?num_oficio={num_oficio}", {})
                    st.success("Ouvidoria encerrada com sucesso!")
                except Exception as e:
                    st.error(f"Erro: {e}")
