-- Seed: TbTipoEvento
INSERT IGNORE INTO TbTipoEvento (tipoevento) VALUES
('Capacitação'),
('Palestra'),
('Oficina'),
('Reunião'),
('Campanha');
