-- Seed: TbTipoAcao
INSERT IGNORE INTO TbTipoAcao (DescricaoAcao) VALUES
('Visita Domiciliar'),
('Atendimento Individual'),
('Encaminhamento'),
('Contato Telefônico'),
('Reunião de Equipe'),
('Articulação Interinstitucional');
