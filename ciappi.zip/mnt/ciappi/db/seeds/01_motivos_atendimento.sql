-- Seed: TbMotivoAtendimento
INSERT IGNORE INTO TbMotivoAtendimento (TbDescricaoMotivo) VALUES
('Violência Física'),
('Violência Psicológica'),
('Violência Sexual'),
('Violência Patrimonial'),
('Abandono'),
('Negligência'),
('Autonegligência');
